Study Hai + Moj Shorts Split Screen

Left: https://study-hai.netlify.app/
Right: https://mojapp.in/?lang=en

The right panel uses Moj's official website, which currently presents Moj short-video content on the web. Extract the ZIP and upload index.html to your hosting service or open it in a modern browser.

Note: Moj may restrict being embedded in another website. If the right panel is blank or shows an error, use the "Moj अलग खोलें" link. A normal ZIP/HTML page cannot override a website's iframe security restrictions. In an APK, behavior also depends on the APK builder's WebView.
